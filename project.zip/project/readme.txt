Contents:

* project.pdf: statement of the project
* project.template.mod: template for writing your model in OPL.
* project.*.dat: toy instances to help you debugging your model.
* project.*.sol: optimal solutions to the project.*.dat instances.
  NOTE THAT OPTIMAL SOLUTIONS MAY NOT BE UNIQUE.
